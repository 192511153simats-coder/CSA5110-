
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char m[5][5] = {
        {'M','F','H','I','K'},
        {'U','N','O','P','Q'},
        {'Z','V','W','X','Y'},
        {'E','L','A','R','G'},
        {'D','S','T','B','C'}
    };
    char s[200], a[200];
    int i,j,n=0,r1,c1,r2,c2;

    printf("Enter plaintext: ");
    fgets(s,sizeof(s),stdin);

    for(i=0;s[i];i++)
        if(isalpha(s[i])) {
            char c=toupper(s[i]);
            if(c=='J') c='I';
            if(n>0 && a[n-1]==c) a[n++]='X';
            a[n++]=c;
        }
    if(n%2) a[n++]='X';

    for(i=0;i<n;i+=2) {
        for(r1=0;r1<5;r1++) for(c1=0;c1<5;c1++)
            if(m[r1][c1]==a[i]) goto found1;
        found1:
        for(r2=0;r2<5;r2++) for(c2=0;c2<5;c2++)
            if(m[r2][c2]==a[i+1]) goto found2;
        found2:
        if(r1==r2) {
            a[i]=m[r1][(c1+1)%5];
            a[i+1]=m[r2][(c2+1)%5];
        } else if(c1==c2) {
            a[i]=m[(r1+1)%5][c1];
            a[i+1]=m[(r2+1)%5][c2];
        } else {
            a[i]=m[r1][c2];
            a[i+1]=m[r2][c1];
        }
    }
    a[n]='\0';
    printf("Ciphertext: %s\n",a);
    return 0;
}
