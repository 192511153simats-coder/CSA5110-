
#include <stdio.h>
#include <ctype.h>

int main() {
    char s[100];
    char key[] = "CIPHERABDFGJKLMNOQSTUVWXYZ";
    int i;
    printf("Enter plaintext: ");
    fgets(s, sizeof(s), stdin);

    for (i = 0; s[i]; i++) {
        if (isupper(s[i]))
            s[i] = key[s[i]-'A'];
        else if (islower(s[i]))
            s[i] = tolower(key[s[i]-'a']);
    }
    printf("Ciphertext: %s", s);
    return 0;
}
