
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char key[100], s[500], m[5][5], used[26]={0};
    int i,j,k=0,n=0,r1,c1,r2,c2;

    printf("Enter keyword: ");
    scanf("%99s",key);
    printf("Enter ciphertext: ");
    scanf(" %499[^\n]",s);

    for(i=0;key[i];i++) {
        char c=toupper(key[i]);
        if(c=='J') c='I';
        if(c>='A'&&c<='Z'&&!used[c-'A']) {
            used[c-'A']=1;
            m[k/5][k%5]=c; k++;
        }
    }
    for(i=0;i<26;i++)
        if(i!='J'-'A'&&!used[i]) {
            m[k/5][k%5]='A'+i; k++;
        }

    for(i=0;s[i];i++)
        if(isalpha(s[i])) {
            char c=toupper(s[i]);
            if(c=='J') c='I';
            s[n++]=c;
        }
    s[n]='\0';

    for(i=0;i+1<n;i+=2) {
        for(r1=0;r1<5;r1++) for(c1=0;c1<5;c1++)
            if(m[r1][c1]==s[i]) goto found1;
        found1:
        for(r2=0;r2<5;r2++) for(c2=0;c2<5;c2++)
            if(m[r2][c2]==s[i+1]) goto found2;
        found2:
        if(r1==r2) {
            s[i]=m[r1][(c1+4)%5];
            s[i+1]=m[r2][(c2+4)%5];
        } else if(c1==c2) {
            s[i]=m[(r1+4)%5][c1];
            s[i+1]=m[(r2+4)%5][c2];
        } else {
            s[i]=m[r1][c2]; s[i+1]=m[r2][c1];
        }
    }
    s[n]='\0';
    printf("Plaintext: %s\n",s);
    return 0;
}
