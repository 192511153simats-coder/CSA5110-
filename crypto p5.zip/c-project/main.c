
#include <stdio.h>
#include <ctype.h>

int main() {
    char s[100];
    int a, b, i;
    printf("Enter text: ");
    fgets(s, sizeof(s), stdin);
    printf("Enter a and b: ");
    scanf("%d%d", &a, &b);

    for (i = 0; s[i]; i++) {
        if (isalpha(s[i])) {
            char base = isupper(s[i]) ? 'A' : 'a';
            s[i] = (a*(s[i]-base)+b)%26+base;
        }
    }
    printf("Ciphertext: %s", s);
    return 0;
}
