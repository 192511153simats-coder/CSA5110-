
#include <stdio.h>
#include <ctype.h>

int main() {
    char s[500];
    int i;
    printf("Enter ciphertext: ");
    fgets(s, sizeof(s), stdin);

    for (i = 0; s[i]; i++) {
        if (isalpha(s[i])) {
            char base = isupper(s[i]) ? 'A' : 'a';
            int c = toupper(s[i]) - 'A';
            s[i] = (9 * ((c - 15 + 26) % 26)) % 26 + base;
        }
    }
    printf("Decrypted text: %s", s);
    return 0;
}
