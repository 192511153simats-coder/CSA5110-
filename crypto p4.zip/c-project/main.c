
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char s[100], key[100];
    int i, j = 0;
    printf("Enter plaintext: ");
    fgets(s, sizeof(s), stdin);
    printf("Enter key: ");
    scanf("%99s", key);

    for (i = 0; s[i]; i++) {
        if (isalpha(s[i])) {
            char base = isupper(s[i]) ? 'A' : 'a';
            s[i] = (s[i]-base + toupper(key[j++ % strlen(key)])-'A') % 26 + base;
        }
    }
    printf("Ciphertext: %s", s);
    return 0;
}
