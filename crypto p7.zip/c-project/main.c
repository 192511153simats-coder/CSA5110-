
#include <stdio.h>
#include <ctype.h>

int main() {
    char s[500], key[27];
    int i;
    printf("Enter cipher alphabet: ");
    scanf("%26s", key);
    printf("Enter ciphertext: ");
    scanf(" %499[^\n]", s);

    for (i = 0; s[i]; i++) {
        if (isalpha(s[i])) {
            char c = toupper(s[i]);
            int j;
            for (j = 0; j < 26; j++)
                if (toupper(key[j]) == c) break;
            if (j < 26)
                s[i] = isupper(s[i]) ? 'A'+j : 'a'+j;
        }
    }
    printf("Plaintext: %s\n", s);
    return 0;
}
