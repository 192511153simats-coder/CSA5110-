
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char key[100], s[200], a[100], m[5][5], used[26]={0};
    int i,j,k=0,r1,c1,r2,c2,n=0;

    printf("Enter key: ");
    scanf("%99s",key);
    printf("Enter plaintext: ");
    scanf(" %199[^\n]",s);

    for(i=0;key[i];i++) {
        char c=toupper(key[i]);
        if(c=='J') c='I';
        if(c>='A'&&c<='Z'&&!used[c-'A']) {
            used[c-'A']=1; m[k/5][k%5]=c; k++;
        }
    }
    for(i=0;i<26;i++)
        if(i!='J'-'A'&&!used[i]) {
            m[k/5][k%5]='A'+i; k++;
        }

    for(i=0;s[i];i++) {
        char c=toupper(s[i]);
        if(c>='A'&&c<='Z') {
            if(c=='J') c='I';
            if(n>0&&a[n-1]==c) a[n++]='X';
            a[n++]=c;
        }
    }
    if(n%2) a[n++]='X';

    for(i=0;i<n;i+=2) {
        for(r1=0;r1<5;r1++) for(c1=0;c1<5;c1++)
            if(m[r1][c1]==a[i]) goto found1;
        found1:
        for(r2=0;r2<5;r2++) for(c2=0;c2<5;c2++)
            if(m[r2][c2]==a[i+1]) goto found2;
        found2:
        if(r1==r2) {
            a[i]=m[r1][(c1+1)%5];
            a[i+1]=m[r2][(c2+1)%5];
        } else if(c1==c2) {
            a[i]=m[(r1+1)%5][c1];
            a[i+1]=m[(r2+1)%5][c2];
        } else {
            a[i]=m[r1][c2]; a[i+1]=m[r2][c1];
        }
    }
    a[n]='\0';
    printf("Ciphertext: %s\n",a);
    return 0;
}
